# setup.py
from setuptools import setup

setup(
    name='my-telebot',
    version='0.1',
    packages=['my_telebot'],
    install_requires=[
        'python-telegram-bot',
    ],
)
